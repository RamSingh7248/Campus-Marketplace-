const mongoose = require("mongoose");

const ProductSchema = new mongoose.Schema({
  title: { type: String, required: true },
  desc: { type: String },
  category: { type: String, default: "Misc" },
  price: { type: Number, required: true },
  image: { type: String },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null }
}, { timestamps: true });

module.exports = mongoose.model("Product", ProductSchema);
