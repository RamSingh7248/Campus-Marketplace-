const express = require("express");
const Product = require("../models/Product");
const jwt = require("jsonwebtoken");
const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "change_me_to_a_long_secret";

// simple auth middleware (optional)
function authOptional(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return next();
  const token = header.split(" ")[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
  } catch {}
  next();
}

function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ message: "Unauthorized" });
  const token = header.split(" ")[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ message: "Invalid token" });
  }
}

// GET /api/products
router.get("/", authOptional, async (req, res) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 }).lean();
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// POST /api/products  (protected)
router.post("/", requireAuth, async (req, res) => {
  try {
    const { title, desc, category, price, image } = req.body;
    if (!title || price == null) return res.status(400).json({ message: "Missing fields" });

    const product = new Product({
      title,
      desc,
      category,
      price,
      image,
      owner: req.user.id
    });
    await product.save();

    // broadcast to sockets if server has io
    const io = req.app.get("io");
    if (io) io.emit("new-product", product);

    res.json({ ok: true, product });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
