// index.js (fixed) - copy entire file and replace existing index.js
require("dotenv").config();
const express = require("express");
const http = require("http");
const mongoose = require("mongoose");
const cors = require("cors");
const { Server } = require("socket.io");
const path = require("path");

const authRoutes = require("./routes/auth");
const productRoutes = require("./routes/products");

const app = express();
const server = http.createServer(app);

// socket.io - allow CORS from frontend origin
const io = new Server(server, {
  cors: { origin: process.env.FRONTEND_ORIGIN || "*", methods: ["GET", "POST"] }
});

app.use(cors());
app.use(express.json());

// serve static frontend if you later want to place files in /public
app.use(express.static(path.join(__dirname, "public")));

// api routes
app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);

// socket.io chat
io.on("connection", (socket) => {
  console.log("socket connected:", socket.id);
  socket.on("chat-message", (payload) => {
    io.emit("chat-message", payload);
  });
  socket.on("disconnect", () => {
    console.log("socket disconnected:", socket.id);
  });
});
app.set("io", io);

// ---------- sanitize MONGO URI ----------
function sanitizeMongoUri(raw) {
  if (!raw || typeof raw !== "string") return raw;

  // if it's a standard mongodb+srv or mongodb URL, try URL parsing
  try {
    // Some connection strings from Atlas include "?" already. URL requires a protocol.
    const u = new URL(raw);

    // Remove unsupported options if present (case-insensitive)
    const banned = ["usenewurlparser", "useunifiedtopology"];
    const params = new URLSearchParams(u.search);
    for (const key of Array.from(params.keys())) {
      if (banned.includes(key.toLowerCase())) params.delete(key);
    }

    // if the params became empty remove the '?'
    const newSearch = params.toString();
    u.search = newSearch ? `?${newSearch}` : "";

    return u.toString();
  } catch (err) {
    // fallback: remove occurrences using regex (case-insensitive)
    return raw.replace(/([?&])(useNewUrlParser|useUnifiedTopology)=[^&]*(&?)/gi, (m,p1,p2,p3) => {
      // if p1 is '?' and there's another param after this (p3 not empty) keep '?', else remove
      if (p1 === "?" && p3) return "?";
      if (p3) return p1; // return either '?' or '&' as separator
      return "";
    });
  }
}

// use environment variable and sanitize it
const RAW_MONGO = process.env.MONGO_URI || process.env.MONGO;
const CLEAN_MONGO = sanitizeMongoUri(RAW_MONGO);

// log masked URI for debugging (password hidden)
function maskUri(uri) {
  try {
    const u = new URL(uri);
    if (u.username || u.password) {
      u.password = "*****";
      u.username = u.username ? u.username : "";
      return u.toString();
    }
    return uri;
  } catch {
    // fallback mask: replace password-ish part
    return String(uri).replace(/:\/\/([^:]+):([^@]+)@/, "://$1:*****@");
  }
}
console.log("Using MONGO_URI:", maskUri(CLEAN_MONGO));

// ---------- connect and start ----------
const PORT = process.env.PORT || 5000;

mongoose
  .connect(CLEAN_MONGO)
  .then(() => {
    console.log("MongoDB connected");
    server.listen(PORT, () => console.log("Server running on port", PORT));
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err);
    process.exit(1);
  });
